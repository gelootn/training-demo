﻿namespace MediatR.Demo.Framework;

public enum MessageType
{
    Info,
    Warning,
    Error
}