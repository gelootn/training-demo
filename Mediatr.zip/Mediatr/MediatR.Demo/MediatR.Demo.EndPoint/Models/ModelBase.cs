﻿namespace MediatR.Demo.EndPoint.Models;

public abstract record ModelBase(int Id);