﻿namespace MediatR.Demo.EndPoint.Models;

public record StopVisitModel(string VisitorEmail);