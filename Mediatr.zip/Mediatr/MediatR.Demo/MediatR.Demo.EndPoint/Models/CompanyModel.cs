﻿namespace MediatR.Demo.EndPoint.Models;

public record CompanyModel(int Id, string Name) : ModelBase(Id);