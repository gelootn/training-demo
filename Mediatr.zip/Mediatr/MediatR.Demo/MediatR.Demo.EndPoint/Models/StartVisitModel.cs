﻿namespace MediatR.Demo.EndPoint.Models;

public record StartVisitModel(string VisitorName, string VisitorEmail, string VisitorCompany, int EmployeeId, int CompanyId);