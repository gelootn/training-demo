﻿namespace MediatR.Demo.Dal.Infrastructure.Filters;

public class VisitFilter
{
    public string? VisitorName { get; set; }
    public string? VisitorEmail { get; set; }
    public string? VisitorCompany { get; set; }
    public string? Employee { get; set; }
    public string? Company { get; set; }
}