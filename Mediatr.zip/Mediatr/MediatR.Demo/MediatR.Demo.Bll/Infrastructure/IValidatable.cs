﻿namespace MediatR.Demo.Bll.Infrastructure;

public interface IValidatable
{
    
}