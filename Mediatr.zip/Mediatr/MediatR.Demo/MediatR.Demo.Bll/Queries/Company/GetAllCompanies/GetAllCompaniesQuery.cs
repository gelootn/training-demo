﻿namespace MediatR.Demo.Bll.Queries.Company.GetAllCompanies;

public class GetAllCompaniesQuery : IRequest<GetAllCompaniesQueryResult>
{
    
}